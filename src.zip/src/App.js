import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";

export default function PersonalWebsite() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#EFE2BA] to-[#C5CBE3] text-gray-800">
      {/* Header Section */}
      <header className="p-6 shadow-md bg-white sticky top-0 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold text-[#D79922]">Dana's Space</h1>
          <nav className="flex gap-6">
            <a href="#about" className="text-gray-600 hover:text-[#F13C20]">About</a>
            <a href="#portfolio" className="text-gray-600 hover:text-[#F13C20]">Portfolio</a>
            <a href="#contact" className="text-gray-600 hover:text-[#F13C20]">Contact</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto">
          <motion.h2
            className="text-4xl font-extrabold text-[#F13C20] mb-4"
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            Hello, I'm Dana
          </motion.h2>
          <p className="text-lg text-gray-600 mb-6">
            A developer who loves clean designs and creative solutions.
          </p>
          <div className="flex flex-col items-center">
            <img
              src="/profile-picture.jpg"
              alt="Dana's profile"
              className="w-32 h-32 rounded-full shadow-lg mb-6"
            />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto text-center">
          <h3 className="text-3xl font-semibold text-[#D79922] mb-4">About Me</h3>
          <p className="text-gray-600 leading-relaxed max-w-3xl mx-auto">
            I graduated from Sejong University with a degree in Computer Science and have experience in Python, Java, and various development tools. I specialize in AI-related projects and building scalable solutions. Outside of coding, I enjoy adding creative touches to every project I undertake.
          </p>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-gradient-to-br from-[#EFE2BA] to-[#C5CBE3]">
        <div className="container mx-auto text-center">
          <h3 className="text-3xl font-semibold text-[#D79922] mb-6">Skills</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {["Python", "Java", "Kubernetes", "Azure", "AI & Machine Learning", "Docker"].map((skill, index) => (
              <Card key={index} className="bg-white shadow-lg rounded-xl">
                <CardContent className="p-4">
                  <h4 className="text-xl font-bold mb-2 text-[#4056A1]">{skill}</h4>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-white">
        <div className="container mx-auto text-center">
          <h3 className="text-3xl font-semibold text-[#D79922] mb-6">Portfolio</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {["Project 1", "Project 2", "Project 3"].map((project, index) => (
              <Card key={index} className="bg-white shadow-lg rounded-xl">
                <CardContent className="p-4">
                  <h4 className="text-xl font-bold mb-2 text-[#4056A1]">{project}</h4>
                  <p className="text-gray-600 text-sm">
                    A brief description of this project goes here.
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="container mx-auto text-center">
          <h3 className="text-3xl font-semibold text-[#D79922] mb-4">Get in Touch</h3>
          <p className="text-gray-600 mb-6">
            Feel free to reach out for collaborations or just a friendly chat.
          </p>
          <form className="max-w-lg mx-auto">
            <input
              type="text"
              placeholder="Your Name"
              className="w-full p-3 mb-4 border border-gray-300 rounded-lg"
            />
            <input
              type="email"
              placeholder="Your Email"
              className="w-full p-3 mb-4 border border-gray-300 rounded-lg"
            />
            <textarea
              placeholder="Your Message"
              className="w-full p-3 mb-4 border border-gray-300 rounded-lg h-32"
            ></textarea>
            <Button className="bg-[#F13C20] hover:bg-[#D79922] text-white px-4 py-2 rounded-lg">
              Send Message
            </Button>
          </form>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="py-6 bg-[#EFE2BA] text-center text-gray-600">
        <p>&copy; 2025 Dana's Space. All Rights Reserved.</p>
      </footer>
    </div>
  );
}